import scipy.io as sio
import numpy as np
import os
import copy
import hdf5storage
import re

def video_order_load(dataset,n_vids):
    datapath = r'D:\sustech\NCC\emo_dataset\data\Remarks_new\vid'
    filesPath = os.listdir(datapath)
    filesPath.sort(key=lambda x: int(re.search(r'\d+', x).group()))
    print(filesPath)
    vid_orders = np.zeros((len(filesPath), n_vids))
    for idx, file in enumerate(filesPath):
    #     # Here don't forget to arange the subjects arrangement
    #     # print(file)
        remark_file = os.path.join(datapath,file)
    #     # subject_remark = hdf5storage.loadmat(remark_file)['After_remark']
        subject_remark = hdf5storage.loadmat(remark_file)
        # vid_orders[idx, :] = [subject_remark[vid][0][2] for vid in range(0,n_vids)]
        # print('idx:', idx)
        # print(subject_remark['vid'][0][0])
        vid_orders[idx, :] = [subject_remark['vid'][0][vid] for vid in range(0,n_vids)]
        # only for vid
        vid_orders[idx, :] = [i - 21 for i in vid_orders[idx, :]]

    # remark_file = os.path.join(datapath,'ima_sub16output_remark.mat')
    # subject_remark = hdf5storage.loadmat(remark_file)
    # vid_orders[0, :] = [subject_remark['vid'][0][vid] for vid in range(0,n_vids)]
    # vid_orders = np.zeros((1, n_vids))
    # vid_orders[0, :] = [subject_remark['vid'][0][vid] for vid in range(0,n_vids)]
    print('vid_order shape: ', vid_orders.shape)
    print('vid_order:', vid_orders)
    return vid_orders



def reorder_vids(data, vid_play_order):
    # data: (n_subs, n_points, n_feas)
    n_vids = int(data.shape[1] / 30)
    print('n_vids:', n_vids)
    n_subs = data.shape[0]
    # Deep copy
    vid_play_order_copy = vid_play_order.copy()

    # if n_vids == 24:
    #     vid_play_order_new = np.zeros((n_subs, n_vids)).astype(np.int32)
    #     data_reorder = np.zeros_like(data)
    #     for sub in range(n_subs):
    #         tmp = vid_play_order_copy[sub,:]
    #         tmp = tmp[(tmp<13)|(tmp>16)]
    #         tmp[tmp>=17] = tmp[tmp>=17] - 4
    #         tmp = tmp - 1
    #         vid_play_order_new[sub, :] = tmp

    #         print('video arrange:', tmp)

    #         data_sub = data[sub, :, :]
    #         data_sub = data_sub.reshape(n_vids, 30, data_sub.shape[-1])
    #         # Error occurs saying that the elements of tmp is not int
    #         tmp = [int(i) for i in tmp]
    #         data_sub = data_sub[tmp, :, :]
    #         data_reorder[sub, :, :] = data_sub.reshape(n_vids*30, data_sub.shape[-1])
    if n_vids == 18:
        vid_play_order_new = np.zeros((n_subs, n_vids)).astype(np.int32)
        data_reorder = np.zeros_like(data)
        for sub in range(n_subs):
            tmp = vid_play_order_copy[sub,:]
            # tmp = tmp[(tmp<10)|(tmp>16)]
            # tmp[tmp>=17] = tmp[tmp>=17] - 4
            tmp = [i for i in tmp if i not in (19,20,21)]
            tmp = np.array(tmp)
            print('tmp:', tmp)
            tmp = tmp - 1
            vid_play_order_new[sub, :] = tmp

            print('video arrange:', tmp)

            data_sub = data[sub, :, :]
            data_sub = data_sub.reshape(n_vids, 30, data_sub.shape[-1])
            # Error occurs saying that the elements of tmp is not int
            tmp = [int(i) for i in tmp]
            data_sub = data_sub[tmp, :, :]  #还原到播放时候的顺序
            data_reorder[sub, :, :] = data_sub.reshape(n_vids*30, data_sub.shape[-1])
            # print("data_reorder:", data_reorder)
    elif n_vids == 16:
        vid_play_order_new = np.zeros((n_subs, n_vids)).astype(np.int32)
        data_reorder = np.zeros_like(data)
        for sub in range(n_subs):
            tmp = vid_play_order_copy[sub,:]
            # tmp = tmp[(tmp<10)|(tmp>16)]
            # tmp[tmp>=17] = tmp[tmp>=17] - 4
            tmp = [i for i in tmp if i not in (14,16,19,20,21)]
            tmp = np.array(tmp)

            for i in range(len(tmp)):
                if tmp[i] == 15:
                    tmp[i] = 14
                if tmp[i] == 17:
                    tmp[i] = 15
                if tmp[i] == 18:
                    tmp[i] = 16

            print('tmp:', tmp)
            tmp = tmp - 1
            vid_play_order_new[sub, :] = tmp

            print('video arrange:', tmp)

            data_sub = data[sub, :, :]
            data_sub = data_sub.reshape(n_vids, 30, data_sub.shape[-1])
            # Error occurs saying that the elements of tmp is not int
            tmp = [int(i) for i in tmp]
            data_sub = data_sub[tmp, :, :]  #还原到播放时候的顺序
            data_reorder[sub, :, :] = data_sub.reshape(n_vids*30, data_sub.shape[-1])
            # print("data_reorder:", data_reorder)
    elif n_vids == 21:
        vid_play_order_new = np.zeros((n_subs, n_vids)).astype(np.int32)
        data_reorder = np.zeros_like(data)
        for sub in range(n_subs):
            tmp = vid_play_order_copy[sub,:]
            # tmp = tmp[(tmp<10)|(tmp>16)]
            # tmp[tmp>=17] = tmp[tmp>=17] - 4
            tmp = [i for i in tmp ]
            tmp = np.array(tmp)
            # print('tmp:', tmp)
            tmp = tmp - 1
            vid_play_order_new[sub, :] = tmp

            print('video arrange:', tmp)

            data_sub = data[sub, :, :]
            data_sub = data_sub.reshape(n_vids, 30, data_sub.shape[-1])
            # Error occurs saying that the elements of tmp is not int
            tmp = [int(i) for i in tmp]
            data_sub = data_sub[tmp, :, :]  #还原到播放时候的顺序
            data_reorder[sub, :, :] = data_sub.reshape(n_vids*30, data_sub.shape[-1])
        
    elif n_vids == 19:
        vid_play_order_new = np.zeros((n_subs, n_vids)).astype(np.int32)
        data_reorder = np.zeros_like(data)
        for sub in range(n_subs):
            tmp = vid_play_order_copy[sub,:]
            tmp[tmp>14] = tmp[tmp>14] - 1
            tmp[tmp>16] = tmp[tmp>16] - 1
            # tmp = tmp[(tmp<10)|(tmp>16)]
            # tmp[tmp>=17] = tmp[tmp>=17] - 4
            tmp = [i for i in tmp ]
            tmp = np.array(tmp)
            # print('tmp:', tmp)
            tmp = tmp - 1
            vid_play_order_new[sub, :] = tmp

            print('video arrange:', tmp)

            data_sub = data[sub, :, :]
            data_sub = data_sub.reshape(n_vids, 30, data_sub.shape[-1])
            # Error occurs saying that the elements of tmp is not int
            tmp = [int(i) for i in tmp]
            data_sub = data_sub[tmp, :, :]

    elif n_vids == 28:
        vid_play_order_new = np.zeros((n_subs, n_vids)).astype(np.int32)
        data_reorder = np.zeros_like(data)

        for sub in range(n_subs):
            tmp = vid_play_order_copy[sub,:]
            tmp = tmp - 1
            vid_play_order_new[sub, :] = tmp

            data_sub = data[sub, :, :]
            data_sub = data_sub.reshape(n_vids, 30, data_sub.shape[-1])
            # Error occurs saying that the elements of tmp is not int
            tmp = [int(i) for i in tmp]
            data_sub = data_sub[tmp, :, :]
            data_reorder[sub, :, :] = data_sub.reshape(n_vids*30, data_sub.shape[-1])

    return data_reorder, vid_play_order_new



def reorder_vids_back(data, vid_play_order_new):
    # data: (n_subs, n_points, n_feas)
    n_vids = int(data.shape[1] / 30)
    n_subs = data.shape[0]

    data_back = np.zeros((n_subs, n_vids, 30, data.shape[-1]))

    for sub in range(n_subs):
        data_sub = data[sub, :, :].reshape(n_vids, 30, data.shape[-1])
        data_back[sub, vid_play_order_new[sub, :], :, :] = data_sub
    data_back = data_back.reshape(n_subs, n_vids*30, data.shape[-1])
    return data_back
