import numpy as np
import h5py
import scipy.io as sio
import pickle
import mne
import os


# Load the data
data_path = r'D:\sustech\NCC\emo_dataset\data\preprocessed_data\ima'
data_paths = os.listdir(data_path)
data_paths.sort()

# name11_ima = 'sub11_ima_reorder.pkl'
# name11_vid = 'sub11_vid_reorder.pkl'
# name16_ima = 'sub16_ima_reorder.pkl'
# name16_vid = 'sub16_vid_reorder.pkl'

# f1 = open(os.path.join(data_path, name11_ima), 'rb')
# data11_ima = pickle.load(f1)
# f2 = open(os.path.join(data_path, name11_vid), 'rb')
# data11_vid = pickle.load(f2)
# f3 = open(os.path.join(data_path, name16_ima), 'rb')
# data16_ima = pickle.load(f3)
# f4 = open(os.path.join(data_path, name16_vid), 'rb')
# data16_vid = pickle.load(f4)

# data11_ima = data11_ima.transpose([1, 0, 2])
# data11_vid = data11_vid.transpose([1, 0, 2])
# data16_ima = data16_ima.transpose([1, 0, 2])
# data16_vid = data16_vid.transpose([1, 0, 2])


n_subs = 20
n_vids = 21;
chn = 64;
fs = 200;
sec = 30;
data = np.zeros((n_subs, n_vids, chn, fs * sec))
# data[0, :, :, :] = data16_ima
for idx, path in enumerate(data_paths):
    f = open(os.path.join(data_path, path), 'rb')
    data_sub = pickle.load(f)
    data[idx, :, :, :] = data_sub[:, :, :].transpose([1, 0, 2])



# data shape :(sub, vid, chn, fs * sec)
print('data loaded:', data.shape)


n_subs = data.shape[0]

fs = 200
freqs = [[1,4], [4,8], [8,14], [14,30], [30,47]]

de = np.zeros((n_subs, 64, n_vids*30, len(freqs)))
for i in range(len(freqs)):
    print('Current freq band: ', freqs[i])
    for sub in range(n_subs):
        for j in range(n_vids):
            data_video = data[sub, j, :, :]
            print(data_video.shape)
            low_freq = freqs[i][0]
            high_freq = freqs[i][1]
            data_video_filt = mne.filter.filter_data(data_video, fs, l_freq=low_freq, h_freq=high_freq)
            data_video_filt = data_video_filt.reshape(64, -1, fs)
            de_one = 0.5*np.log(2*np.pi*np.exp(1)*(np.var(data_video_filt, 2)))
            # n_subs, chs, 28*30, freqs
            de[sub, :, 30*j: 30*(j+1), i] = de_one

    
print(de.shape)
de = {'de': de}
sio.savemat('./ima_de_features.mat', de)